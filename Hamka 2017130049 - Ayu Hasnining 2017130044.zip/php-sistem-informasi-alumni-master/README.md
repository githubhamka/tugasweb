# Config URL	
	dbconnect.php
		Ganti Variable $pathUpload dan $pathUrl dengan struktur folder kalian masing"

# Import SQL
	sistem_informasi_alumni.sql

# User 
	user : 1
	password : password